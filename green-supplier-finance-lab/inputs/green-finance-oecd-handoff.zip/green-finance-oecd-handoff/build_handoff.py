#!/usr/bin/env python3
"""Green-finance OECD handoff bundle (data only; NO finance/investment calc).

For ONE explicitly named buyer country x industry, extract from the OECD ICIO 2025
(2022 table) a tidy first-tier supplier table (buyer, supplier country, supplier
industry, intermediate input flow, supplier gross output, supplier value added),
and attach production-based GHG by matching country x industry from OECD GHGFP
(DF_MAIN, PROD_GHG). Missing GHG matches are preserved as null.

Buyer: DEU_C29 = Germany, Manufacture of motor vehicles, trailers and semi-trailers.
"""
import csv, json, sys, hashlib, datetime, os
csv.field_size_limit(10**7)
SP = os.path.dirname(os.path.abspath(__file__))
ICIO = os.path.join(SP, "oecdho", "2022_SML.csv")
GHG  = os.path.join(SP, "oecdho", "main2", "DF_MAIN.csv")   # MAIN_csv.zip: PROD_GHG to 2022
OECD = os.environ.get("OECD_DATA_DIR", os.path.join(SP, "OECD"))
ICIO_ZIP = os.path.join(OECD, "ICIO", "2025", "Regular", "2016-2022_SML.zip")
GHG_ZIP  = os.path.join(OECD, "GHG Datasets", "MAIN_csv.zip")
OUT = os.environ.get("OECD_HANDOFF_OUT", SP)
BUYER = "DEU_C29"; GHG_YEAR = "2022"; ICIO_YEAR = "2022"
os.makedirs(OUT, exist_ok=True)

def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    return h.hexdigest()

# ---- GHG production emissions (PROD_GHG, tonnes CO2e; UNIT_MULT 6 => Mt) ----
ghg = {}
with open(GHG, encoding="utf-8", newline="") as f:
    r = csv.reader(f); next(r)
    for row in r:
        yr, meas, area, act, unit, mult, val = row[0], row[1], row[2], row[3], row[4], row[5], row[6]
        if meas == "PROD_GHG" and yr == GHG_YEAR and unit == "T_CO2E":
            try: ghg[(area, act)] = float(val)   # already in millions of tonnes (mult=6)
            except ValueError: pass
ghg_acts = {a for (_, a) in ghg}

# ---- ICIO buyer column extraction ----
FD = ("HFCE","NPISH","GGFC","GFCF","INVNT","DPABR")
with open(ICIO, encoding="utf-8", newline="") as f:
    r = csv.reader(f); header = next(r)
    jbuy = header.index(BUYER); jout = header.index("OUT")
    suppliers = []; va_by_col = None
    for row in r:
        lab = row[0]
        if lab == "VA":
            va_by_col = {header[k]: row[k] for k in range(1, len(header))}
            continue
        if lab in ("OUT", "TLS"): continue
        if "_" not in lab: continue
        # skip final-demand rows if any slipped in
        if lab.split("_", 1)[1] in FD: continue
        try: flow = float(row[jbuy])
        except ValueError: flow = 0.0
        if flow > 0:
            try: out = float(row[jout])
            except ValueError: out = None
            suppliers.append((lab, flow, out))

def split(lab): c, i = lab.split("_", 1); return c, i
rows_out = []
tot_flow = 0.0; matched = 0
for lab, flow, out in suppliers:
    c, ind = split(lab)
    va = va_by_col.get(lab); va = float(va) if va not in (None, "") else None
    g = ghg.get((c, ind)); mtch = (c, ind) in ghg
    matched += mtch; tot_flow += flow
    rows_out.append({"buyer": BUYER, "supplier_country": c, "supplier_industry": ind,
                     "intermediate_input_flow_usd_mn": round(flow, 4),
                     "supplier_gross_output_usd_mn": round(out, 4) if out is not None else None,
                     "supplier_value_added_usd_mn": round(va, 4) if va is not None else None,
                     "prod_ghg_2022_MtCO2e": round(g, 6) if g is not None else None,
                     "ghg_matched": mtch})
rows_out.sort(key=lambda d: -d["intermediate_input_flow_usd_mn"])

# buyer's own totals + production GHG
bc, bi = split(BUYER)
with open(ICIO, encoding="utf-8", newline="") as f:
    r = csv.reader(f); header = next(r); jout = header.index("OUT")
    buyer_out = buyer_va = None
    for row in r:
        if row[0] == BUYER: buyer_out = float(row[jout])
        if row[0] == "VA": buyer_va = float(row[header.index(BUYER)])
buyer_ghg = ghg.get((bc, bi))

# ---- write supplier CSV ----
sup_csv = os.path.join(OUT, "first_tier_suppliers_DEU_C29_ICIO2022.csv")
with open(sup_csv, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows_out[0].keys())); w.writeheader(); w.writerows(rows_out)

# ---- manifest ----
manifest = {
    "title": "Green-finance OECD handoff — first-tier suppliers + production GHG (DATA ONLY)",
    "buyer": {"code": BUYER, "country": "Germany (DEU)", "industry": "C29 Motor vehicles, trailers & semi-trailers",
              "icio_year": ICIO_YEAR, "gross_output_usd_mn": round(buyer_out,4) if buyer_out else None,
              "value_added_usd_mn": round(buyer_va,4) if buyer_va else None,
              "production_ghg_2022_MtCO2e": round(buyer_ghg,6) if buyer_ghg else None},
    "supplier_table": {"file": "first_tier_suppliers_DEU_C29_ICIO2022.csv",
                       "rows": len(rows_out), "total_intermediate_inflow_usd_mn": round(tot_flow,3),
                       "ghg_matched_rows": matched, "ghg_unmatched_rows": len(rows_out)-matched},
    "units": {"monetary": "USD million, current basic prices (OECD ICIO 2025, SML/standard release; see ReadMe_ICIO_small.xlsx)",
              "ghg": "Million tonnes CO2-equivalent (Mt CO2e), production-based emissions (PROD_GHG)"},
    "definitions": {"intermediate_input_flow": "ICIO Z[supplier_row, DEU_C29 column], 2022 — intermediate deliveries from each supplier country-industry to the buyer.",
                    "supplier_gross_output": "ICIO OUT column at the supplier row (total gross output).",
                    "supplier_value_added": "ICIO VA row at the supplier's own column.",
                    "production_ghg": "OECD GHGFP DF_MAIN PROD_GHG (territorial/production emissions) by country x industry."},
    "compatibility_and_mismatches": [
        f"YEAR: SAME YEAR — ICIO input-output table {ICIO_YEAR} matched to production GHG {GHG_YEAR}. Production GHG taken from the MAIN extract (GHG Datasets/MAIN_csv.zip, PROD_GHG to 2022), NOT the older DF_MAIN_csv.zip which ends at 2020.",
        "INDUSTRY CONCORDANCE: matched on identical ICIO/GHG codes only. ICIO codes finer than GHG for some sectors (e.g. C24A/C24B vs GHG C24; C301/C302T309 vs GHG C30; A01/A02 vs GHG A01_02) -> those suppliers have ghg_matched=false and null GHG (missing preserved).",
        "ROW: intermediate flows only (final demand columns excluded); VA/TLS/OUT rows excluded from suppliers.",
        "ICIO 2022 and GHG 2022 values may include provisional/nowcast estimates per OECD."],
    "exclusions": "No finance, investment cost, abatement, or buyer-support values are computed or implied. This is observed IO + GHG data only.",
    "sources": {
        "icio": {"name": "OECD Inter-Country Input-Output (ICIO) 2025 release, table 2022 (SML)",
                 "file": "ICIO/2025/Regular/2016-2022_SML.zip -> 2022_SML.csv",
                 "zip_sha256": sha256(ICIO_ZIP),
                 "url": "https://www.oecd.org/en/data/datasets/inter-country-input-output-tables.html"},
        "ghg": {"name": "OECD Greenhouse Gas Footprints, production-based emissions (PROD_GHG), MAIN extract with series to 2022",
                "file": "GHG Datasets/MAIN_csv.zip -> DF_MAIN.csv (PROD_GHG to 2022; distinct from DF_MAIN_csv.zip which ends 2020)",
                "zip_sha256": sha256(GHG_ZIP),
                "url": "https://www.oecd.org/en/data/datasets/greenhouse-gas-emissions-embodied-in-international-trade.html"}},
    "download_date": "2026-09-20",
    "generated": datetime.date.today().isoformat(),
    "note": "For the separate green-finance prototype. Preserve missing matches; do not claim observed finance."}
json.dump(manifest, open(os.path.join(OUT, "manifest.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)

print("BUNDLE:", OUT)
print(f"suppliers: {len(rows_out)} rows, total inflow {tot_flow:,.0f} USD mn, GHG matched {matched}/{len(rows_out)}")
print(f"buyer DEU_C29 output {buyer_out:,.0f} / VA {buyer_va:,.0f} USD mn / prod GHG {GHG_YEAR} {buyer_ghg} Mt")
